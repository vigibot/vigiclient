#!/bin/bash

fichier=colors.cpp

g++ $fichier -o ${fichier%.*} \
-O2 \
-lopencv_core \
-lopencv_imgcodecs \
-lopencv_imgproc \
-lopencv_videoio \
-lwiringPi
