#!/bin/bash

./colors | ffmpeg -s:v 640x480 -pix_fmt rgb8 -f rawvideo -i pipe: \
                  -c:v h264_omx -profile:v baseline -b:v 1500000 -flags:v +global_header -bsf:v dump_extra \
                  -y -f rawvideo test.264
