#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <opencv2/opencv.hpp>
#include <opencv2/videoio.hpp>
#include <wiringSerial.h>

#define WIDTH 640
#define HEIGHT 480
#define FPS 30

#define DEVROBOT "/dev/pts/1"
#define DEVDEBIT 115200
#define REMOTEFRAMESIZE 17
#define TELEMETRYFRAMESIZE 25
#define HEADERSIZE 4
#define NBCOMMANDS 2

#define BINNING 2
//#define NBCOLORS 12
#define NBCOLORS 7
#define THRESHOLD 60
#define EPSILON 1.0
#define MINVERTICES 3
#define MINAREA 20.0
#define MINCOLORDIST 2
#define MINPOINTPOLYGONDIST -20.0

#define TIMEOUT 30
#define NEUTRAL 10
#define KPX 3
#define KDX 9
#define KPY 2
#define KDY 4
#define XMIN -13500
#define XMAX 13500
#define YMIN -5500
#define YMAX 5500
#define KVY 200
#define VMIN 16
#define KVZ 2

enum {
 SELECTCAMERA,
 SELECTCAMERASHORTS,
 SELECTCONFTHRESHOLD,
 SELECTCONFFIRSTCOLOR
};

/*const char *COLORS[] = {"Red", "Orange", "Yellow", "Yellow-green",
                        "Green", "Green-cyan", "Cyan", "Cyan-blue",
                        "Blue", "Blue-magenta", "Magenta", "Magenta-red"};
const char *SHORTS[] = {"R", "O", "Y", "YG",
                        "G", "GC", "C", "CB",
                        "B", "BM", "M", "MR"};*/
const char *COLORS[] = {"Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Magenta"};
const char *SHORTS[] = {"R", "O", "Y", "G", "C", "B", "M"};

using namespace std;
using namespace cv;

typedef struct {
 union {
  struct {
   uint8_t header[HEADERSIZE];
   int16_t xy[NBCOMMANDS][2];
   uint8_t z;
   int8_t vx;
   int8_t vy;
   int8_t vz;
   uint8_t switchs;
  };

  uint8_t bytes[REMOTEFRAMESIZE];
 };
} RemoteFrame;

typedef struct {
 union {
  struct {
   uint8_t header[HEADERSIZE];
   //uint32_t lat;
   //uint32_t lon;
   int16_t xy[NBCOMMANDS][2];
   uint16_t voltage;
   uint16_t battery;
   uint8_t z;
   int8_t vx;
   int8_t vy;
   int8_t vz;
   uint8_t switchs;
   uint8_t cpuload;
   uint8_t soctemp;
   uint8_t link;
   uint8_t rssi;
   //uint8_t satsActive;
   //uint8_t speed;
   //uint8_t track;
  };

  uint8_t bytes[TELEMETRYFRAMESIZE];
 };
} TelemetryFrame;

typedef struct Feature {
 int color;
 vector<Point> polygon;
 float area;
 Point2f center;
 Point circleCenter;
 int circleRadius;
 bool filtered;
} Feature;

RemoteFrame remoteFrame;
TelemetryFrame telemetryFrame;
vector<Feature> features;
int width;
int height;
int fps;

volatile bool run = true;

//uchar hues[] = {7, 22, 37, 52, 67, 82, 97, 112, 127, 142, 157, 172};
uchar hues[] = {7, 22, 37, 82, 97, 134, 164};

uchar hueToColor[180];
uchar colorToHue[NBCOLORS];
Scalar hueToBgr[180];

bool blacks[NBCOLORS] = {false};
