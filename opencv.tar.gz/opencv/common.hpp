int mapInteger(int n, int inMin, int inMax, int outMin, int outMax);
double mapDouble(double n, double inMin, double inMax, double outMin, double outMax);
int constrain(int n, int min, int max);
double constrain(double n, double min, double max);
