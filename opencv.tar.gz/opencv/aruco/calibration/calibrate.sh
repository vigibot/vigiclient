#!/bin/bash

./calibrate_camera_charuco -d=0 -h=5 -w=8 --ml=.016 --sl=.028 --rs --sc calibration.yaml
